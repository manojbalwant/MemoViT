# Reproducibility

This document records the exact per-benchmark settings and the open code issues
that must be resolved before a clean reproduction. It is the single source of
truth for anything that differs across benchmarks.

## Per-benchmark settings

| Benchmark | Resolution | Normalization | Heatmap Gaussian σ | CLS-PCA |
|---|---|---|---|---|
| Drone-Anomaly (aerial) | 518 × 518 | dataset-specific (computed at runtime) | none | off |
| UIT-ADrone (aerial) | 518 × 518 | dataset-specific (computed at runtime) | none | off |
| Agriculture-Vision | 512 → 518 | dataset-specific (computed at runtime) | σ = 4 | off |
| VisA (industrial) | 518 × 518 | ImageNet (μ=[.485,.456,.406], σ=[.229,.224,.225]) | σ = 4 | off |
| MVTec-AD (industrial) | 518 × 518 | ImageNet | σ = 4 | off |

Notes:
- **Evaluation resolution** `S_eval`: 518 for aerial pipelines; native 512 × 512 for
  Agriculture-Vision tiles; native ground-truth mask resolution for MVTec-AD / VisA.
- DINOv2 was pretrained under ImageNet normalization. The aerial and
  Agriculture-Vision pipelines currently use dataset-specific statistics; re-running
  them under ImageNet statistics, for full consistency with the backbone, is a
  recommended ablation (see issue #8).
- CLS-PCA (exact SVD, k = 512) is enabled only for the baseline-comparison and
  ablation experiments; frame AUC varies < 0.2 points across k ∈ {128, …, 1024}.

## Reported vs. diagnostic scores

Each script computes three frame/image scores and prints all of them:

| Name | What it is | Reported? |
|---|---|---|
| `robust_patch_score` (Eq. 7) | robust-MAD aggregation of per-patch discrepancy | **Yes** |
| `cls_proto` | per-layer CLS-vs-prototype aggregation | No (diagnostic) |
| `concat_knn` | concatenated multi-layer CLS k-NN distance | No (diagnostic) |

The canonical reported scorer lives in [`scoring.py`](scoring.py). All result
tables (1–8) use `robust_patch_score`.

## Known issues / release checklist

These were identified during a code-to-manuscript audit. Items resolved in this
release are checked; the canonical scorer now lives in `src/scoring.py` and is
imported by all five scripts.

- [x] **#7 (was blocker)** `baselines.py` (`ProposedModel.score()`) now returns
      the reported `robust_patch_score` (Eq. 7) instead of `cls_score`. The CLS
      and concat scores are retained in `self.last_diagnostics` for inspection.
- [x] **#2** The CLS-proto score is no longer named `frame_auroc`/`frame_auc`.
      It is renamed `cls_proto_auroc` (`ablation.py`) and `cls_proto_auc`
      (`aerial_memovit.py`); the reported metric is `patch_auroc`/`patch_auc`,
      now explicitly labelled "reported, Eq. 7" in console output and tables.
- [x] Duplicate `robust_patch_score` definitions removed from `ablation.py`
      (defined twice), `aerial_memovit.py`, `mvtec_visa_memovit.py`, and
      `agriculture_memovit.py`; all import from `scoring.py`.
- [x] **#11** Ablation table headers relabelled: the CLS column is marked
      diagnostic, the patch column "reported (Eq. 7)", and the CLS-PCA panel
      columns corrected ("CLS-PCA type", "CLS-key dim").
- [x] **#8** Per-benchmark normalization documented above (code and paper agree).
- [x] **#9** Gaussian smoothing (σ = 4 for MVTec/VisA and Agriculture, none for
      aerial) documented above and parameterised in `scoring.anomaly_heatmap`.
- [ ] **#10** The layer ablation still varies both the retrieval key and the
      patch-discrepancy layer (the last selected block). For a clean retrieval-key
      ablation, fix the patch layer at block 11 and vary only the CLS key layers.
      *(Left open — requires a new experimental run, not a code fix.)*
- [ ] Fill the missing `double_plant` AUPRO entry in the Agriculture-Vision table,
      or annotate the omission. *(Left open — requires recomputation.)*

## Determinism

Seed 42 everywhere; `torch.backends.cudnn.deterministic = True`,
`torch.backends.cudnn.benchmark = False`. The ablation runner repeats over seeds
`[42, 123, 7]`, reports mean ± std, and runs paired Wilcoxon signed-rank tests
across variants.

## Reference environment

Single NVIDIA A100 80 GB; PyTorch 1.12.1 / CUDA 10.2; batch size 16, 8 workers.
Bank build ≈ 12 min per 10k retained frames; inference ≈ 12 ms/frame including FAISS retrieval.
